<template>
 <div class="wrap">

   <el-tabs type="border-card">
     <el-tab-pane label="影像检索">
      <el-button type="primary" size="small">搜索</el-button>
      <!-- 数据集选择 -->
      <div >
         <el-button type="primary" size="mini">选择数据集</el-button>
         *点击选择数据集
      </div>
      <!-- 地图范围的选择 -->
        <div class="tab_table">
        <el-tabs v-model="activeName" >
          <!-- 行政区 -->
          <el-tab-pane label="行政区" name="first">
            <el-cascader
              placeholder="省直辖市/地级市州/区县旗"
              :options="options_city"
              @active-item-change="handleItemChange"
              :props="props"
              size="mini"
              change-on-select="true"
            ></el-cascader>
          </el-tab-pane>
      <!-- 经纬度 -->
          <el-tab-pane label="经纬度" name="second">
             经度：<input type="text" class="input_coordinate"> </input>
             到 <input type="text" class="input_coordinate"> </input>
             纬度：<input type="text" class="input_coordinate"> </input>
             到<input type="text" class="input_coordinate"> </input>
          </el-tab-pane>
      <!-- 行列号 -->
          <el-tab-pane label="行列号" name="third">
              path：<input type="text" class="input_coordinate"> </input>
             到<input type="text" class="input_coordinate"> </input>
             row：<input type="text" class="input_coordinate"> </input>
             到<input type="text" class="input_coordinate"> </input>
          </el-tab-pane>
      <!-- 地图选择 -->
          <el-tab-pane label="地图选择" name="fourth">
              <el-button type="plain" size="mini" icon="el-icon-search">点选择</el-button>
              <el-button type="plain" size="mini" icon="el-icon-search">线选择</el-button>
              <el-button type="plain" size="mini" icon="el-icon-search">面选择</el-button>
         </el-tab-pane>
      <!-- 矢量文件 -->
          <el-tab-pane label="矢量文件" name="firth">
              <!-- 上传按钮，功能还没有实现 -->
              <el-button plain size="mini">上传</el-button>
              *选择矢量文件上传
          </el-tab-pane>

        </el-tabs>
        </div>
        <!-- 时间选择 -->
        <div class="dataTime">

          时间范围：
          <el-date-picker
                size="mini"
                v-model="value6"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期">
              </el-date-picker>
        </div>
     </el-tab-pane>
     <!-- 上传影像 -->
     <el-tab-pane label="上传影像">
       <el-button plain size="mini">上传</el-button>
              *选择TM影像上传
     </el-tab-pane>

   </el-tabs>

   <!-- 取消按钮    功能还没哟偶实现-->
   <div class="cancel">
   <el-button type="plain" icon="el-icon-d-arrow-left"></el-button>
   </div>
  <div>

  </div>
 </div>
</template>

<script>
  export default {
    data() {
      return {
        //标签
                activeName: 'first',
                 value6: '',
                 valueDate:'',//日期选择
                //省直辖市列表？
                options_city: [{
                  label: '江苏',
                  cities: []
                  }, {
                  label: '浙江',
                  cities: []
                }],
              //省市及其子项
                props: {
                  value: 'label',
                  children: 'cities'
                },

      };
    },

    methods: {

      //省市县的响应跳转
      handleItemChange(val) {
        console.log('active item:', val);
        setTimeout(_ => {
        if (val.indexOf('江苏') > -1 && !this.options_city[0].cities.length) {
        this.options_city[0].cities = [{
        label: '南京',
        cities:[]
        }, {
        label: '南通',
        }];
        } else if (val.indexOf('浙江') > -1 && !this.options_city[1].cities.length) {
        this.options_city[1].cities = [{
        label: '杭州'
        }];
        }
        }, 300);
      },
  //文件上传demo

      },




  };
</script>

<style>
  .wrap{
    width:480px
   }
 .el-tabs__header{
   width:420px;
 }
.cancel{
  position: absolute;
  top:8px;
  left:430px;
}
  /* 行政区 级联选择器属性修改 */
/* 地点检索 */
.tab_table{
  width:400px;
 }
.el-tab-pane{
  width: 400px;
  }
  .el-cascader{
    width: 400px;
  }
  .el-input__suffix-inner{
    width: 10px;
  }
 .el-cascader-menu{
   min-width:130px;
 }
.el-cascader-node{
  padding:0 3px 0 2px;
}
.el-cascader-node__label{
  padding:0 0 0 10px;
}
.el-cascader-node__postfix{
  right:0;
}
.input_coordinate{
  width: 50px;
  display: inline;
  height: 20px;
}

/* 日期选择 属性修改 */
.dataTime{

  top: 130px;
  width: 400px;
}
.el-date-editor--daterange.el-input,
 .el-date-editor--daterange.el-input__inner,
 .el-date-editor--timerange.el-input,
 .el-date-editor--timerange.el-input__inner{
  width: 315px;
}


</style>
