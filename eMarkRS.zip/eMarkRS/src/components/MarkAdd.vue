<template>
<div class="wrap">
  <!-- 命名栏 -->
    对象名称：
  <input type="text" placeholder="请输入标注名称"></input>
   <el-checkbox v-model="checked">显示/隐藏</el-checkbox>
   <!-- 信息栏 -->
   <div class="sheji">
   <el-tabs v-model="activeName2" type="card" size="mini" @tab-click="handleClick">
      <el-tab-pane label="说明" name="first">
       <input class="said" type="text" />
       </el-tab-pane>
       <el-tab-pane label="空间信息" name="second">
        <el-table
           ref="singleTable"
           :data="tableData"
           highlight-current-row
           @current-change="handleCurrentChange"
           style="width: 100%">
           <el-table-column
             type="index"
             width="20">
           </el-table-column>
           <el-table-column
             property="date"
             label="X"
             width="100">
           </el-table-column>
           <el-table-column
             property="name"
             label="Y"
             width="100">
           </el-table-column>
           <el-table-column
             property="address"
             label="Z">
           </el-table-column>
         </el-table>
         </el-tab-pane>
       <el-tab-pane label="投影信息" name="third">点没有投影信息，线有长度，面有周长和面积</el-tab-pane>
       <el-tab-pane label="样式" name="fourth">样式设计</el-tab-pane>
     </el-tabs>
 </div>
 <!-- 底部按钮 -->
 <el-button-group>
<el-button>导出坐标点</el-button>
<el-button>定位</el-button>
<el-button>确认</el-button>
<el-button>取消</el-button>
</el-button-group>
</div>
</template>

<script>
  export default {
    data(){
      return{
         checked: true,
         activeName2: 'first',
         // 空间信息
         tableData: [],
         currentRow: null

      };
    },
    methods: {
          //tab事件
          handleClick(tab, event) {
            console.log(tab, event);
          },
          //空间信息表格
           setCurrent(row) {
                  this.$refs.singleTable.setCurrentRow(row);
                },
                handleCurrentChange(val) {
                  this.currentRow = val;
                }
              }

        }


</script>

<style>
  .wrap{
    width:350px;

    border:gainsboro solid thin;

  }
.said{
  height:137px;
  width: 328px;
}
.sheji{
   width: 333px;
   height: 200px;
   border:gainsboro solid thin;
   }
</style>
